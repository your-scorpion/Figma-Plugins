/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./src/plugin/controller.ts":
/*!**********************************!*\
  !*** ./src/plugin/controller.ts ***!
  \**********************************/
/***/ (function() {

var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
figma.showUI(__html__, { width: 640, height: 536 });
figma.ui.onmessage = (msg) => {
    const newDat22a = msg.capturedDataURLData;
    const heightheight = msg.height;
    const widthwidth = msg.width;
    let x = 0;
    if (msg.type === 'create-rectangles') {
        const nodes = [];
        const rectPromises = [];
        for (let i = 0; i < msg.count; i++) {
            function getRandomValue() {
                return Math.random() * 1400 - 700;
            }
            const rect = figma.createRectangle();
            rect.x = getRandomValue();
            rect.y = x;
            rect.resize(widthwidth * 2, heightheight * 2);
            const imagePromise = figma.createImageAsync(newDat22a);
            rectPromises.push(imagePromise.then((image) => {
                rect.fills = [
                    {
                        type: 'IMAGE',
                        imageHash: image.hash,
                        scaleMode: 'FILL',
                    },
                ];
                return rect;
            }));
            figma.currentPage.appendChild(rect);
            nodes.push(rect);
            x += rect.width + 32;
            if (i > 0 && i % 2 === 1) {
                x += 640;
            }
        }
        Promise.all(rectPromises).then((rects) => {
            rects.forEach((rect) => {
                nodes.push(rect);
            });
            figma.currentPage.selection = [nodes[0]];
            const selectedNode = nodes[0];
            const zoomToSelection = () => __awaiter(this, void 0, void 0, function* () {
                yield figma.loadFontAsync({ family: 'Roboto', style: 'Regular' });
                figma.viewport.scrollAndZoomIntoView([selectedNode]);
            });
            zoomToSelection();
            figma.ui.postMessage({
                type: 'create-rectangles',
                message: `Created ${msg.count} Rectangles`,
            });
        });
    }
};


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./src/plugin/controller.ts"]();
/******/ 	
/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29kZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQTtBQUNBLDRCQUE0QiwrREFBK0QsaUJBQWlCO0FBQzVHO0FBQ0Esb0NBQW9DLE1BQU0sK0JBQStCLFlBQVk7QUFDckYsbUNBQW1DLE1BQU0sbUNBQW1DLFlBQVk7QUFDeEYsZ0NBQWdDO0FBQ2hDO0FBQ0EsS0FBSztBQUNMO0FBQ0EseUJBQXlCLHlCQUF5QjtBQUNsRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Esd0JBQXdCLGVBQWU7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLHFCQUFxQjtBQUNyQjtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBYTtBQUNiO0FBQ0E7QUFDQTtBQUNBLDRDQUE0QyxvQ0FBb0M7QUFDaEY7QUFDQSxhQUFhO0FBQ2I7QUFDQTtBQUNBO0FBQ0Esb0NBQW9DLFdBQVc7QUFDL0MsYUFBYTtBQUNiLFNBQVM7QUFDVDtBQUNBOzs7Ozs7OztVRTdEQTtVQUNBO1VBQ0E7VUFDQTtVQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vZmlnbWEtcGx1Z2luLXJlYWN0LXRlbXBsYXRlLy4vc3JjL3BsdWdpbi9jb250cm9sbGVyLnRzIiwid2VicGFjazovL2ZpZ21hLXBsdWdpbi1yZWFjdC10ZW1wbGF0ZS93ZWJwYWNrL2JlZm9yZS1zdGFydHVwIiwid2VicGFjazovL2ZpZ21hLXBsdWdpbi1yZWFjdC10ZW1wbGF0ZS93ZWJwYWNrL3N0YXJ0dXAiLCJ3ZWJwYWNrOi8vZmlnbWEtcGx1Z2luLXJlYWN0LXRlbXBsYXRlL3dlYnBhY2svYWZ0ZXItc3RhcnR1cCJdLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgX19hd2FpdGVyID0gKHRoaXMgJiYgdGhpcy5fX2F3YWl0ZXIpIHx8IGZ1bmN0aW9uICh0aGlzQXJnLCBfYXJndW1lbnRzLCBQLCBnZW5lcmF0b3IpIHtcclxuICAgIGZ1bmN0aW9uIGFkb3B0KHZhbHVlKSB7IHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFAgPyB2YWx1ZSA6IG5ldyBQKGZ1bmN0aW9uIChyZXNvbHZlKSB7IHJlc29sdmUodmFsdWUpOyB9KTsgfVxyXG4gICAgcmV0dXJuIG5ldyAoUCB8fCAoUCA9IFByb21pc2UpKShmdW5jdGlvbiAocmVzb2x2ZSwgcmVqZWN0KSB7XHJcbiAgICAgICAgZnVuY3Rpb24gZnVsZmlsbGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yLm5leHQodmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxyXG4gICAgICAgIGZ1bmN0aW9uIHJlamVjdGVkKHZhbHVlKSB7IHRyeSB7IHN0ZXAoZ2VuZXJhdG9yW1widGhyb3dcIl0odmFsdWUpKTsgfSBjYXRjaCAoZSkgeyByZWplY3QoZSk7IH0gfVxyXG4gICAgICAgIGZ1bmN0aW9uIHN0ZXAocmVzdWx0KSB7IHJlc3VsdC5kb25lID8gcmVzb2x2ZShyZXN1bHQudmFsdWUpIDogYWRvcHQocmVzdWx0LnZhbHVlKS50aGVuKGZ1bGZpbGxlZCwgcmVqZWN0ZWQpOyB9XHJcbiAgICAgICAgc3RlcCgoZ2VuZXJhdG9yID0gZ2VuZXJhdG9yLmFwcGx5KHRoaXNBcmcsIF9hcmd1bWVudHMgfHwgW10pKS5uZXh0KCkpO1xyXG4gICAgfSk7XHJcbn07XHJcbmZpZ21hLnNob3dVSShfX2h0bWxfXywgeyB3aWR0aDogNjQwLCBoZWlnaHQ6IDUzNiB9KTtcclxuZmlnbWEudWkub25tZXNzYWdlID0gKG1zZykgPT4ge1xyXG4gICAgY29uc3QgbmV3RGF0MjJhID0gbXNnLmNhcHR1cmVkRGF0YVVSTERhdGE7XHJcbiAgICBjb25zdCBoZWlnaHRoZWlnaHQgPSBtc2cuaGVpZ2h0O1xyXG4gICAgY29uc3Qgd2lkdGh3aWR0aCA9IG1zZy53aWR0aDtcclxuICAgIGxldCB4ID0gMDtcclxuICAgIGlmIChtc2cudHlwZSA9PT0gJ2NyZWF0ZS1yZWN0YW5nbGVzJykge1xyXG4gICAgICAgIGNvbnN0IG5vZGVzID0gW107XHJcbiAgICAgICAgY29uc3QgcmVjdFByb21pc2VzID0gW107XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBtc2cuY291bnQ7IGkrKykge1xyXG4gICAgICAgICAgICBmdW5jdGlvbiBnZXRSYW5kb21WYWx1ZSgpIHtcclxuICAgICAgICAgICAgICAgIHJldHVybiBNYXRoLnJhbmRvbSgpICogMTQwMCAtIDcwMDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb25zdCByZWN0ID0gZmlnbWEuY3JlYXRlUmVjdGFuZ2xlKCk7XHJcbiAgICAgICAgICAgIHJlY3QueCA9IGdldFJhbmRvbVZhbHVlKCk7XHJcbiAgICAgICAgICAgIHJlY3QueSA9IHg7XHJcbiAgICAgICAgICAgIHJlY3QucmVzaXplKHdpZHRod2lkdGggKiAyLCBoZWlnaHRoZWlnaHQgKiAyKTtcclxuICAgICAgICAgICAgY29uc3QgaW1hZ2VQcm9taXNlID0gZmlnbWEuY3JlYXRlSW1hZ2VBc3luYyhuZXdEYXQyMmEpO1xyXG4gICAgICAgICAgICByZWN0UHJvbWlzZXMucHVzaChpbWFnZVByb21pc2UudGhlbigoaW1hZ2UpID0+IHtcclxuICAgICAgICAgICAgICAgIHJlY3QuZmlsbHMgPSBbXHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0eXBlOiAnSU1BR0UnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpbWFnZUhhc2g6IGltYWdlLmhhc2gsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNjYWxlTW9kZTogJ0ZJTEwnLFxyXG4gICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBdO1xyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlY3Q7XHJcbiAgICAgICAgICAgIH0pKTtcclxuICAgICAgICAgICAgZmlnbWEuY3VycmVudFBhZ2UuYXBwZW5kQ2hpbGQocmVjdCk7XHJcbiAgICAgICAgICAgIG5vZGVzLnB1c2gocmVjdCk7XHJcbiAgICAgICAgICAgIHggKz0gcmVjdC53aWR0aCArIDMyO1xyXG4gICAgICAgICAgICBpZiAoaSA+IDAgJiYgaSAlIDIgPT09IDEpIHtcclxuICAgICAgICAgICAgICAgIHggKz0gNjQwO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFByb21pc2UuYWxsKHJlY3RQcm9taXNlcykudGhlbigocmVjdHMpID0+IHtcclxuICAgICAgICAgICAgcmVjdHMuZm9yRWFjaCgocmVjdCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgbm9kZXMucHVzaChyZWN0KTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIGZpZ21hLmN1cnJlbnRQYWdlLnNlbGVjdGlvbiA9IFtub2Rlc1swXV07XHJcbiAgICAgICAgICAgIGNvbnN0IHNlbGVjdGVkTm9kZSA9IG5vZGVzWzBdO1xyXG4gICAgICAgICAgICBjb25zdCB6b29tVG9TZWxlY3Rpb24gPSAoKSA9PiBfX2F3YWl0ZXIodGhpcywgdm9pZCAwLCB2b2lkIDAsIGZ1bmN0aW9uKiAoKSB7XHJcbiAgICAgICAgICAgICAgICB5aWVsZCBmaWdtYS5sb2FkRm9udEFzeW5jKHsgZmFtaWx5OiAnUm9ib3RvJywgc3R5bGU6ICdSZWd1bGFyJyB9KTtcclxuICAgICAgICAgICAgICAgIGZpZ21hLnZpZXdwb3J0LnNjcm9sbEFuZFpvb21JbnRvVmlldyhbc2VsZWN0ZWROb2RlXSk7XHJcbiAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB6b29tVG9TZWxlY3Rpb24oKTtcclxuICAgICAgICAgICAgZmlnbWEudWkucG9zdE1lc3NhZ2Uoe1xyXG4gICAgICAgICAgICAgICAgdHlwZTogJ2NyZWF0ZS1yZWN0YW5nbGVzJyxcclxuICAgICAgICAgICAgICAgIG1lc3NhZ2U6IGBDcmVhdGVkICR7bXNnLmNvdW50fSBSZWN0YW5nbGVzYCxcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgfSk7XHJcbiAgICB9XHJcbn07XHJcbiIsIiIsIi8vIHN0YXJ0dXBcbi8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuLy8gVGhpcyBlbnRyeSBtb2R1bGUgaXMgcmVmZXJlbmNlZCBieSBvdGhlciBtb2R1bGVzIHNvIGl0IGNhbid0IGJlIGlubGluZWRcbnZhciBfX3dlYnBhY2tfZXhwb3J0c19fID0ge307XG5fX3dlYnBhY2tfbW9kdWxlc19fW1wiLi9zcmMvcGx1Z2luL2NvbnRyb2xsZXIudHNcIl0oKTtcbiIsIiJdLCJuYW1lcyI6W10sInNvdXJjZVJvb3QiOiIifQ==